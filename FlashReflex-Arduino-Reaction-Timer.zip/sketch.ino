#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <Servo.h>

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET -1
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

const int buttonPin = 2;
const int redLedPin = 8;
const int greenLedPin = 9;
const int buzzerPin = 10;
const int servoPin = 6;

Servo scoreServo;

void setup() {
  pinMode(buttonPin, INPUT_PULLUP);
  pinMode(redLedPin, OUTPUT);
  pinMode(greenLedPin, OUTPUT);
  pinMode(buzzerPin, OUTPUT);
  
  scoreServo.attach(servoPin);
  scoreServo.write(0);

  if(!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    for(;;);
  }
  
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(10, 20);
  display.print("Reflex Game Ready!");
  display.display();
  delay(2000);
}

void loop() {
  display.clearDisplay();
  display.setCursor(0, 10);
  display.println("Press button");
  display.println("to start game...");
  display.display();

  // Wait for button press to start
  while (digitalRead(buttonPin) == HIGH) {
    delay(10);
  }

  // Clear debounce
  delay(200);

  display.clearDisplay();
  display.setCursor(0, 10);
  display.println("Get Ready...");
  display.display();

  digitalWrite(redLedPin, HIGH);
  
  // Random wait time between 2 to 5 seconds
  long waitTime = random(2000, 5000);
  delay(waitTime);

  digitalWrite(redLedPin, LOW);
  digitalWrite(greenLedPin, HIGH);
  tone(buzzerPin, 10000, 150);

  unsigned long startTime = millis();
  bool pressed = false;
  unsigned long reactionTime = 0;

  while (millis() - startTime < 2000) {
    if (digitalRead(buttonPin) == LOW) {
      reactionTime = millis() - startTime;
      pressed = true;
      break;
    }
  }

  digitalWrite(greenLedPin, LOW);

  display.clearDisplay();
  display.setCursor(0, 10);

  if (pressed) {
    display.print("Reaction Time:\n");
    display.print(reactionTime);
    display.print(" ms");
    
    int angle = map(constrain(reactionTime, 200, 1500), 200, 1500, 180, 0);
    scoreServo.write(angle);
  } else {
    digitalWrite(buzzerPin, 500);
    delay(500);
    noTone(buzzerPin);
    display.print("Too Slow! Try Again.");
    scoreServo.write(0);
  }

  display.display();
  delay(4000);
}